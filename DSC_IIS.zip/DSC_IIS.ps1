Configuration Configure-Website
{
  param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]     
        [string]$MachineName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]     
        [string]$WebSitePrefix,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]     
        [string]$TypeOfEnv,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]     
        [string]$PublicDNS

  )

  Node $MachineName
  {  
        
         #Install the IIS Role
          WindowsFeature IIS
         {
          Ensure = �Present�
          Name = �Web-Server�
         }

         #Install ASP.NET 4.5
         WindowsFeature ASP
         {
          Ensure = �Present�
          Name = �Web-Asp-Net45�
         }

         WindowsFeature WebServerManagementConsole
         {
          Name = "Web-Mgmt-Console"
          Ensure = "Present"
         }

         # if($TypeOfEnv = 'Tst')
         # {
             # File testfolder
             # {
                # Type = 'Directory'
                # DestinationPath = 'C:\inetpub\wwwroot\test'
                # Ensure = "Present"
                # DependsOn       = '[WindowsFeature]ASP'
             # }

              # xWebsite tstWebsite
             # {
                # Ensure          = 'Present'
                # Name            = $WebSitePrefix + '-tst'
                # State           = 'Started'
                # PhysicalPath    = 'C:\inetpub\wwwroot\test'
                # BindingInfo     = @( MSFT_xWebBindingInformation
                                     # {
                                       # Protocol              = "HTTP"
                                       # Port                  = 80
                                       # HostName = $DevPublicDNS
                                     # }

                                    # )
                # DependsOn       = '[File]testfolder'

             # } 
         # }
         # if($TypeOfEnv = 'PreProd')
         # {

              # File preprodfolder
             # {
                # Type = 'Directory'
                # DestinationPath = 'C:\inetpub\wwwroot\PreProd'
                # Ensure = "Present"
                # DependsOn       = '[WindowsFeature]ASP'
             # }  

             # xWebsite PreProdtWebsite
             # {
                # Ensure          = 'Present'
                # Name            = $WebSitePrefix +'-PreProd'
                # State           = 'Started'
                # PhysicalPath    = 'C:\inetpub\wwwroot\PreProd'
                # BindingInfo     = @( MSFT_xWebBindingInformation
                                     # {
                                       # Protocol              = "HTTP"
                                       # Port                  = 80
                                       # HostName = $UatPublicDNS
                                     # }

                                    # )
                # DependsOn       = '[File]preprodfolder'
             # }
         # }

         # if($TypeOfEnv = 'Prod')
         # {
              # File prodfolder
             # {
                # Type = 'Directory'
                # DestinationPath = 'C:\inetpub\wwwroot\prod'
                # Ensure = "Present"
                # DependsOn       = '[WindowsFeature]ASP'
             # }
             # xWebsite prodWebsite
             # {
                # Ensure          = 'Present'
                # Name            = $WebSitePrefix +'-prod'
                # State           = 'Started'
                # PhysicalPath    = 'C:\inetpub\wwwroot\prod'
                # BindingInfo     = @( MSFT_xWebBindingInformation
                                     # {
                                       # Protocol              = "HTTP"
                                       # Port                  = 80
                                       # HostName = $ProdPublicDNS
                                     # }

                                    # )
                # DependsOn       = '[File]prodfolder'
             # }
        # }
  }
} 